package book.library;

import java.util.List;

public interface ISubscription {

	public List<Subscription> getAll();
	public boolean updateSubscription(Subscription subscription);
}
