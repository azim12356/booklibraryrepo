package book.library;

import java.io.File;

import org.hibernate.SessionFactory;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;


public class HibernateDBConfig {

    private static final SessionFactory sessionFactory = buildSessionFactory();

    private static SessionFactory buildSessionFactory() {
        try {
        	
        	SessionFactory sessionFactory;
			/*
			 * String home = System.getenv("TOMCAT_HOME"); String propertyFilePath = home +
			 * "\\lib\\config\\hibernate.cfg.xml";
			 */
			String propertyFilePath = "C:\\Projects\\map\\3rdpartyapps\\apache-tomcat-9.0.0\\lib\\training\\hibernate.cfg.xml";
			
        	File config = new File(propertyFilePath);   
        	StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
        	    .configure(config) 
        	    .build();
        	try 
        	{
        		  sessionFactory = new MetadataSources(registry)
        	        .buildMetadata().buildSessionFactory();
        	}
        	catch (Exception e) {
        	    e.printStackTrace();
        	    StandardServiceRegistryBuilder.destroy( registry );
        	    throw e;
        	}

           /* // load from different directory
            SessionFactory sessionFactory = new Configuration().configure(
            		propertyFilePath)
                    .buildSessionFactory();*/

            return sessionFactory;

        } catch (Throwable ex) {
            // Make sure you log the exception, as it might be swallowed
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public static void shutdown() {
        // Close caches and connection pools
        getSessionFactory().close();
    }

}
