package book.library;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.io.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController

@RequestMapping("/booklibrary")
public class BookLibraryRestController {
	private static Log log = LogFactory.getLog(BookLibraryRestController.class);

	@Autowired
	private IBookDao bookService;
	
	@Autowired
	private ISubscription subscriptionService;
	

	@GetMapping(value = "/book/all")
	public ResponseEntity<List<Book>> getAllBooks() {

		List<Book> resp = bookService.getAll();

		if (ObjectUtils.isEmpty(resp)) {
			return new ResponseEntity<>(HttpStatus.OK);
		}

		return new ResponseEntity<>(resp, HttpStatus.OK);
	}
	
	@GetMapping(value = "/subscription/all")
	public ResponseEntity<List<Subscription>> getAllSubscriptions() {

		List<Subscription> resp = subscriptionService.getAll();

		if (ObjectUtils.isEmpty(resp)) {
			return new ResponseEntity<>(HttpStatus.OK);
		}

		return new ResponseEntity<>(resp, HttpStatus.OK);
	}
	

	@PostMapping(value = "/subscription/save")
	public ResponseEntity<Boolean> saveOrUpdateSubscription(
			@RequestBody Subscription subscription) {

		boolean resp = subscriptionService.updateSubscription(subscription);

		if (ObjectUtils.isEmpty(resp)) {
			return new ResponseEntity<>(HttpStatus.OK);
		}

		return new ResponseEntity<>(resp, HttpStatus.OK);
	}
	
}
