package book.library;

import java.util.List;

public interface IBookDao {

	public List<Book> getAll();
	
}
