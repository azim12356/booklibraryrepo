package book.library;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;


@Entity
@Table(name = "SUBSCRIPTION")
public class Subscription implements Serializable {

	private static final long serialVersionUID = 1L;

    
	@Column(name = "SUBSCRIBER_NAME")
	private String subscriber_name;

	@Column(name = "DATE_SUBSCRIBED")
	private Date date_subscribed;

	@Column(name = "DATE_RETURNED")
	private Date date_returned;
	
	@Column(name = "BOOK_ID")
	private String book_id;
	
	@Id
	@ManyToOne
	@JoinColumn(name="BOOK_ID", referencedColumnName="BOOK_ID")
	private Book book;

	public Subscription() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Subscription(String subscriber_name, Date date_subscribed, Date date_returned, String book_id, Book book) {
		super();
		this.subscriber_name = subscriber_name;
		this.date_subscribed = date_subscribed;
		this.date_returned = date_returned;
		this.book_id = book_id;
		this.book = book;
	}

	public String getSubscriber_name() {
		return subscriber_name;
	}

	public void setSubscriber_name(String subscriber_name) {
		this.subscriber_name = subscriber_name;
	}

	public Date getDate_subscribed() {
		return date_subscribed;
	}

	public void setDate_subscribed(Date date_subscribed) {
		this.date_subscribed = date_subscribed;
	}

	public Date getDate_returned() {
		return date_returned;
	}

	public void setDate_returned(Date date_returned) {
		this.date_returned = date_returned;
	}

	public String getBook_id() {
		return book_id;
	}

	public void setBook_id(String book_id) {
		this.book_id = book_id;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	
	

}
