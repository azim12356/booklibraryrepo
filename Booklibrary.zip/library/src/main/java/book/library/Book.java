package book.library;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name = "BOOK")
public class Book  {

	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "BOOK_ID")
	private String book_id;
	
	@Column(name = "BOOK_NAME")
	private String book_name;

	@Column(name = "AUTHOR")
	private String author;

	@Column(name = "AVAILABLE_COPIES")
	private int available_copies;
	
	@Column(name = "TOTAL_COPIES")
	private int total_copies;

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Book(int total_copies, String author, String book_id, String book_name, int available_copies) {
		super();
		this.total_copies = total_copies;
		this.author = author;
		this.book_id = book_id;
		this.book_name = book_name;
		this.available_copies = available_copies;
	}

	public String getBook_id() {
		return book_id;
	}

	public void setBook_id(String book_id) {
		this.book_id = book_id;
	}

	public String getBook_name() {
		return book_name;
	}

	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public int getAvailable_copies() {
		return available_copies;
	}

	public void setAvailable_copies(int available_copies) {
		this.available_copies = available_copies;
	}

	public int getTotal_copies() {
		return total_copies;
	}

	public void setTotal_copies(int total_copies) {
		this.total_copies = total_copies;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	

}
