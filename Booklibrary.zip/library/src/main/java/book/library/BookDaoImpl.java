package book.library;


import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Component;


@Component
public class BookDaoImpl implements IBookDao {
	private SessionFactory factory;
	Session session;
	private static Log log = LogFactory.getLog(BookDaoImpl.class);
	private boolean keepSesionOpen = false;

	Transaction trasaction = null;

	protected Session getSession() {
		return this.factory.getCurrentSession();
	}

	public BookDaoImpl() {
		factory = HibernateDBConfig.getSessionFactory();
		session = factory.getCurrentSession();
	}

	public BookDaoImpl(boolean keepSesionOpen) {
		factory = HibernateDBConfig.getSessionFactory();
		session = factory.getCurrentSession();
		this.keepSesionOpen = true;
	}

	public void beginTransaction() {
		trasaction = session.beginTransaction();
	}

	public void commitTransaction() {
		try {
			trasaction.commit();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void closeSession() {
		try {
			if (session != null) {
				session.close();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Override
	public List<Book> getAll() {
		List<Book> allBook = null;
		session = factory.getCurrentSession();
		trasaction = null;
		try {
			beginTransaction();

			CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
			CriteriaQuery<Book> criteriaQuery = criteriaBuilder.createQuery(Book.class);
			Root<Book> rootEntry = criteriaQuery.from(Book.class);
			CriteriaQuery<Book> allQuery = criteriaQuery.select(rootEntry);

			TypedQuery<Book> typedQuery = session.createQuery(allQuery);
			allBook = typedQuery.getResultList();
			trasaction.commit();
		} catch (HibernateException e) {
			if (trasaction != null)
				trasaction.rollback();
			log.error("Book load fails" + e.getMessage());
			e.printStackTrace();
		} finally {
			if (!keepSesionOpen)
				session.close();
		}

		return allBook;
	}

	
}
