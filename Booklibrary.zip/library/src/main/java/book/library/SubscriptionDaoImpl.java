package book.library;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Component;



@Component
public class SubscriptionDaoImpl implements ISubscription {
	private SessionFactory factory;
	Session session;
	private static Log log = LogFactory.getLog(SubscriptionDaoImpl.class);
	private boolean keepSesionOpen = false;

	Transaction transaction = null;

	protected Session getSession() {
		return this.factory.getCurrentSession();
	}

	public SubscriptionDaoImpl() {
		factory = HibernateDBConfig.getSessionFactory();
		session = factory.getCurrentSession();
	}

	public SubscriptionDaoImpl(boolean keepSesionOpen) {
		factory = HibernateDBConfig.getSessionFactory();
		session = factory.getCurrentSession();
		this.keepSesionOpen = true;
	}

	public void beginTransaction() {
		transaction = session.beginTransaction();
	}

	public void commitTransaction() {
		try {
			transaction.commit();
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void closeSession() {
		try {
			if (session != null) {
				session.close();
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	@Override
	public List<Subscription> getAll() {
		List<Subscription> allsub = null;
		session = factory.getCurrentSession();
		transaction = null;
		try {
			beginTransaction();

			CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
			CriteriaQuery<Subscription> criteriaQuery = criteriaBuilder.createQuery(Subscription.class);
			Root<Subscription> rootEntry = criteriaQuery.from(Subscription.class);
			CriteriaQuery<Subscription> allQuery = criteriaQuery.select(rootEntry);

			TypedQuery<Subscription> typedQuery = session.createQuery(allQuery);
			allsub = typedQuery.getResultList();
			transaction.commit();
		} catch (HibernateException e) {
			if (transaction != null)
				transaction.rollback();
			log.error("sub load fails" + e.getMessage());
			e.printStackTrace();
		} finally {
			if (!keepSesionOpen)
				session.close();
		}

		return allsub;
	}

	

	@Override
	public boolean updateSubscription(Subscription sub) {
		boolean isUpdate = false;
		session = factory.getCurrentSession();
		transaction = null;
		try {
			beginTransaction();
			Subscription ressub = session.get(Subscription.class, sub.getBook_id());

			ressub.setBook_id(sub.getBook_id());
			ressub.setSubscriber_name(sub.getSubscriber_name());
			ressub.setDate_subscribed(sub.getDate_subscribed());
					
			session.update(ressub);
			transaction.commit();
			isUpdate = true;
		} catch (HibernateException e) {
			if (transaction != null)
				transaction.rollback();
			log.error("Exception while updating subscription " + e.getMessage());
			e.printStackTrace();
		} finally {
			session.close();
		}

		return isUpdate;
	}

}
